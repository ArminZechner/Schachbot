#include "Display.h"
// 'pawn_black', 16x16px
const unsigned char epd_bitmap_pawn_black [] PROGMEM = {
	0xf8, 0x1f, 0xf0, 0x0f, 0xe0, 0x07, 0xe0, 0x07, 0xe0, 0x07, 0xf0, 0x0f, 0xe0, 0x07, 0xc0, 0x03, 
	0x80, 0x01, 0x80, 0x01, 0x80, 0x01, 0xc0, 0x03, 0x80, 0x01, 0x00, 0x00, 0x00, 0x00, 0x80, 0x01
};
// 'tower_black', 16x16px
const unsigned char epd_bitmap_tower_black [] PROGMEM = {
	0x1c, 0x38, 0x1c, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x01, 0xc0, 0x03, 
	0xe0, 0x07, 0xe0, 0x07, 0xe0, 0x07, 0xe0, 0x07, 0xe0, 0x07, 0x80, 0x01, 0x80, 0x01, 0x00, 0x00
};
// 'horse_black', 16x16px
const unsigned char epd_bitmap_horse_black [] PROGMEM = {
	0xd9, 0xff, 0xc8, 0x9f, 0xc0, 0x07, 0x80, 0x03, 0x90, 0x03, 0x00, 0x03, 0x00, 0x01, 0x00, 0x01, 
	0x00, 0x01, 0x88, 0x01, 0xf8, 0x01, 0xf0, 0x01, 0xc0, 0x00, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00
};
// 'bishop_black', 16x16px
const unsigned char epd_bitmap_bishop_black [] PROGMEM = {
	0xfe, 0x7f, 0xfc, 0x3f, 0xfc, 0x3f, 0xfe, 0x7f, 0xfc, 0x3f, 0xf8, 0x1f, 0xe0, 0x07, 0xc0, 0x03, 
	0xc0, 0x03, 0xe0, 0x07, 0xf8, 0x1f, 0xf0, 0x0f, 0xf8, 0x1f, 0x9c, 0x39, 0x00, 0x00, 0x00, 0x00
};
// 'queen_black', 16x16px
const unsigned char epd_bitmap_queen_black [] PROGMEM = {
	0xfe, 0x7f, 0xe4, 0x27, 0xc0, 0x03, 0xc0, 0x03, 0xe0, 0x07, 0x90, 0x19, 0x08, 0x30, 0x08, 0x30, 
	0x80, 0x01, 0xf0, 0x0f, 0xf0, 0x0f, 0xf8, 0x1f, 0xf8, 0x1f, 0xf0, 0x0f, 0xc0, 0x03, 0x80, 0x01
};
// 'king_black', 16x16px
const unsigned char epd_bitmap_king_black [] PROGMEM = {
	0xff, 0xff, 0xfe, 0x7f, 0xfc, 0x3f, 0xf8, 0x1f, 0xc8, 0x13, 0x84, 0x21, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0xc0, 0x03, 0xe0, 0x07, 0xf0, 0x0f, 0xf0, 0x0f, 0xf0, 0x0f, 0xf0, 0x0f, 0xf8, 0x1f
};
// Array of all bitmaps for convenience. (Total bytes used to store images in PROGMEM = 288)
const int epd_bitmap_allArray_LEN = 6;
const unsigned char* epd_bitmap_allArray[6] = {
	epd_bitmap_pawn_black,
	epd_bitmap_tower_black,
	epd_bitmap_horse_black,
	epd_bitmap_bishop_black,
	epd_bitmap_queen_black,
	epd_bitmap_king_black
};

Display::Display(){
       //this->display = display;
       tft.begin();
       tft.setRotation(1);
       selectedFields[0].x = -1;
       selectedFields[0].y = -1;
       selectedFields[1].x = -1;
       selectedFields[1].y = -1;
}
void Display::setSelectedFields(Koordinate field1, Koordinate field2){
       selectedFields[0] = field1;
       selectedFields[1] = field2;
}
void Display::setChessBoard(char soll_schachbrett[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y],
                            char soll_schachbrettFriedhof[2][SCHACHBRETT_SCHLAGBREITE][SCHACHBRETT_SIZE_Y]){
    memcpy(
        this->soll_schachbrett,
        soll_schachbrett,
        sizeof(this->soll_schachbrett)
    );

    memcpy(
        this->soll_schachbrettFriedhof,
        soll_schachbrettFriedhof,
        sizeof(this->soll_schachbrettFriedhof)
    );
}
void Display::printMessage(String message){
        this->message = message;
        tft.setCursor(10,10);
        tft.setTextSize(2);
        tft.setTextColor(TFT_BLACK, TFT_WHITE);
        Serial.printf("%s\n", message.c_str());
        tft.printf("%s", message.c_str());
}
int getPieceWithOutColor(int p) {
    if (p == e_figuren::empty) {
        return empty;
    }
    if (p >= e_figuren::whitePawn &&
        p <= e_figuren::whiteKing) {
        return p;
    }
    else {
        return p - 6;
    }
}
void Display::printChessfield(){
    bool schachMuster = false;
    for(int y = 0; y < 8; y++){
        for(int x = 0; x < 2; x++){
            schachMuster ? tft.fillRect(FIELD_SIZE_X * x, FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(31, 47, 63)) :
            tft.fillRect(FIELD_SIZE_X * x, FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(79, 108, 138));
            
            schachMuster ? tft.fillRect(FIELD_SIZE_X * (x + 10), FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(70, 30, 28)) :
            tft.fillRect(FIELD_SIZE_X * (x + 10), FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(120, 50, 40));
            if(soll_schachbrettFriedhof[0][x][y] != e_figuren::empty){
            tft.drawBitmap(x*FIELD_SIZE_X, y*FIELD_SIZE_Y, epd_bitmap_allArray[getPieceWithOutColor(soll_schachbrettFriedhof[0][x][y])], 16, 16, TFT_BLACK);
            }
            if(soll_schachbrettFriedhof[1][x][y] != e_figuren::empty){
            tft.drawBitmap(x*FIELD_SIZE_X, y*FIELD_SIZE_Y, epd_bitmap_allArray[getPieceWithOutColor(soll_schachbrettFriedhof[1][x][y])], 16, 16, TFT_BLACK);
            }
            schachMuster = !schachMuster;
        }
        schachMuster = !schachMuster;
    }
    for(int y = 0; y < 8; y++){
        for(int x = 2; x < 10; x++){
            schachMuster ? tft.fillRect(FIELD_SIZE_X * x, FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(115, 149, 82)) :
            tft.fillRect(FIELD_SIZE_X * x, FIELD_SIZE_Y * y, FIELD_SIZE_X, FIELD_SIZE_Y, tft.color565(235, 236, 208));
            if(soll_schachbrett[x-2][y] != e_figuren::empty){
            tft.drawBitmap(x*FIELD_SIZE_X, y*FIELD_SIZE_Y, epd_bitmap_allArray[getPieceWithOutColor(soll_schachbrett[x-2][y])], 16, 16, TFT_BLACK);
            }
            schachMuster = !schachMuster;
        }
        schachMuster = !schachMuster;
    }
}