#include "StockfishAPI.h"

#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>

#include "Common.h"

#define LICHESS_API_URL "https://lichess.org/api/cloud-eval"

StockfishAPI::StockfishAPI()
{
    _lastEvaluation = 0;
}

int StockfishAPI::getLastEvaluation() const
{
    return _lastEvaluation;
}

MoveResult StockfishAPI::getTurn(
    char board[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y],
    bool whiteTurn
)
{
    String fen = boardToFEN(board, whiteTurn);

    Serial.println("=== GENERATED FEN ===");
    Serial.println(fen);

    return requestStockfish(fen);
}

char StockfishAPI::pieceToFen(char piece)
{
    switch(piece)
    {
        case whitePawn:   return 'P';
        case whiteTower:  return 'R';
        case whiteHorse:  return 'N';
        case whiteBishop: return 'B';
        case whiteQueen:  return 'Q';
        case whiteKing:   return 'K';

        case blackPawn:   return 'p';
        case blackTower:  return 'r';
        case blackHorse:  return 'n';
        case blackBishop: return 'b';
        case blackQueen:  return 'q';
        case blackKing:   return 'k';

        case empty:
        default:
            return 0;
    }
}

String StockfishAPI::boardToFEN(
    char board[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y],
    bool whiteTurn
)
{
    String fen = "";

    // Schwarz oben / Weiß unten
    for(int y = 7; y >= 0; y--)
    {
        int emptyCount = 0;

        for(int x = 0; x < 8; x++)
        {
            // ACHTUNG:
            // dein Board ist [x][y]
            char piece = board[x][y];

            if(piece == empty)
            {
                emptyCount++;
                continue;
            }

            char f = pieceToFen(piece);

            if(f == 0)
            {
                emptyCount++;
                continue;
            }

            if(emptyCount > 0)
            {
                fen += String(emptyCount);
                emptyCount = 0;
            }

            fen += f;
        }

        if(emptyCount > 0)
        {
            fen += String(emptyCount);
        }

        if(y > 0)
        {
            fen += "/";
        }
    }

    fen += whiteTurn ? " w " : " b ";

    // keine Rochade / en passant aktuell
    fen += "- - 0 1";

    return fen;
}

MoveResult StockfishAPI::requestStockfish(const String& fen)
{
    MoveResult result;

    result.success = false;
    result.bestMove = "";
    result.pv = "";
    result.evaluation = 0;
    result.mateIn = 0;
    result.depth = 0;

    if(WiFi.status() != WL_CONNECTED)
    {
        Serial.println("WiFi not connected");
        return result;
    }

    HTTPClient https;

    String encodedFen = fen;
    encodedFen.replace(" ", "%20");

    String url =
        String(LICHESS_API_URL) +
        "?fen=" + encodedFen +
        "&multiPv=1";

    Serial.println("=== REQUEST URL ===");
    Serial.println(url);

    WiFiClientSecure *client = new WiFiClientSecure;

    client->setInsecure();
    client->setTimeout(15000);

    if(!https.begin(*client, url))
    {
        Serial.println("HTTPS begin failed");

        delete client;
        return result;
    }

    https.addHeader("Accept", "application/json");

    int httpCode = https.GET();

    if(httpCode <= 0)
    {
        Serial.printf("HTTP ERROR: %d\n", httpCode);

        https.end();
        delete client;

        return result;
    }

    Serial.printf("HTTP CODE: %d\n", httpCode);

    String payload = https.getString();

    https.end();
    delete client;

    Serial.println("=== RESPONSE ===");
    Serial.println(payload);

    DynamicJsonDocument doc(8192);

    DeserializationError error = deserializeJson(doc, payload);

    if(error)
    {
        Serial.println("JSON parse error");
        return result;
    }

    if(doc.containsKey("cp"))
    {
        result.evaluation = doc["cp"];
    }

    if(doc.containsKey("mate"))
    {
        result.mateIn = doc["mate"];
    }

    if(doc.containsKey("depth"))
    {
        result.depth = doc["depth"];
    }

    String moves = "";

    if(doc.containsKey("pv"))
    {
        moves = doc["pv"].as<String>();
    }
    else if(doc.containsKey("pvs") && doc["pvs"].size() > 0)
    {
        moves = doc["pvs"][0]["moves"] | "";
    }

    if(moves.length() > 0)
    {
        int firstSpace = moves.indexOf(' ');

        if(firstSpace > 0)
        {
            result.bestMove = moves.substring(0, firstSpace);
        }
        else
        {
            result.bestMove = moves;
        }

        result.pv = moves;
        result.success = true;
    }
    else
    {
        Serial.println("NO MOVES RETURNED");
    }

    _lastEvaluation = result.evaluation;

    return result;
}