#include <Arduino.h>
#include "Tastenmatrix.h"
#include "Gantry.h"
#include "Display.h"
#include "ZugCheck.h"
#include "StockfishAPI.h"
#include "WifiManagerWrapper.h"

#define ROWS 4
#define COLS 4

struct TIME_PERIODE{
  unsigned long getKey = 0;
  unsigned long zusatzZeitKey = 0;
  unsigned long wlanConnect = 0;
};

TIME_PERIODE timePeriode;

Display display;
Gantry gantry;
Tastenmatrix tasten;
ZugCheck zugCheck;
StockfishAPI stockfish;

WifiManagerWrapper wifi;

void setup() {
    Serial.begin(115200);
    Serial.println("SYSTEM_START");
    timePeriode.getKey = millis();
    gantry.init();
    zugCheck.init();
    display.setChessBoard(zugCheck.soll_schachbrett, zugCheck.soll_schachbrettFriedhof);

    display.printChessfield();
    Serial.println("Start Programm");
    display.printMessage("Start Programm");

    wifi.begin();
}


void loop() {
    gantry.move();
    wifi.handle();
    if ((millis()-timePeriode.getKey)>(50+timePeriode.zusatzZeitKey)) {
      timePeriode.zusatzZeitKey = 0;
      if(tasten.getKey() == true){
        timePeriode.zusatzZeitKey = 300;
      }
      timePeriode.getKey = millis();
    }
    if(tasten.checkifBufferIsFull()){
      Serial.printf("[%d,%d] [%d,%d]\n", tasten.getEingabe(0).x, tasten.getEingabe(0).y, tasten.getEingabe(1).x, tasten.getEingabe(1).y);
      zugCheck.moveFigure(tasten.getEingabe(0).x, tasten.getEingabe(0).y,
                          tasten.getEingabe(1).x, tasten.getEingabe(1).y);
      gantry.goTo((Koordinate){(int8_t)(tasten.getEingabe(0).x + 2), tasten.getEingabe(0).y},
                  (Koordinate){(int8_t)(tasten.getEingabe(1).x + 2), tasten.getEingabe(1).y});
      tasten.clearKeyMatrix();
      MoveResult result;
      result = stockfish.getTurn(zugCheck.soll_schachbrett, !zugCheck.currentColor);
      Serial.printf("Result: %s, %d, %d\n", result.bestMove.c_str(), result.evaluation, zugCheck.currentColor);
    }
    delay(1);
}