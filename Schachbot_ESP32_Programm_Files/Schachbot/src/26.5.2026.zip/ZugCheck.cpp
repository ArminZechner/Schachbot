#include "ZugCheck.h"
#include <cstdlib>
#include <stdio.h>

enum colorPiece {
    white,
    black
};
enum towers {
    towerLeft,
    towerRight
};
void ZugCheck::init() {
    for (int y = 0; y < 8; y++) {
        for (int x = 0; x < 8; x++) {
            soll_schachbrett[x][y] = schachbrettInitialisierung[y][x];
        }
    }
    for (int y = 0; y < SCHACHBRETT_SIZE_Y; y++) {
        for (int x = 0; x < SCHACHBRETT_SCHLAGBREITE; x++) {
            soll_schachbrettFriedhof[colorPiece::white][x][y] = e_figuren::empty;
            soll_schachbrettFriedhof[colorPiece::black][x][y] = e_figuren::empty;
        }
    }
}

int ZugCheck::getWhiteOrBlack(int x, int y) {
    if (soll_schachbrett[x][y] == e_figuren::empty) {
        return 2;
    }
    if (soll_schachbrett[x][y] >= e_figuren::whitePawn &&
        soll_schachbrett[x][y] <= e_figuren::whiteKing) {
        return colorPiece::white;
    }
    else {
        return colorPiece::black;
    }
}
int ZugCheck::direction(int pos, int dest) {
    if (pos > dest) {
        return -1;
    }
    else {
       return 1;
    }
}

bool ZugCheck::checkIfMoveIsOnTheChessfield(int x, int y, int destX, int destY) {
    if (x < 0 || x > SCHACHBRETT_SIZE_Y - 1 ||
        y < 0 || y > SCHACHBRETT_SIZE_Y ||
        destX < 0 || destX > SCHACHBRETT_SIZE_Y - 1 ||
        destY < 0 || destY > SCHACHBRETT_SIZE_Y) {
        return false;
    }
    return true;
}
int ZugCheck::getPieceWithOutColor(int p) {
    if (p == e_figuren::empty) {
        return empty;
    }
    if (p >= e_figuren::whitePawn &&
        p <= e_figuren::whiteKing) {
        return p;
    }
    else {
        return p - 6;
    }
}
void ZugCheck::stelleGeschlageneFigurZurueck(int destX, int destY) {
    char piece = soll_schachbrett[destX][destY];
    int xAdd = currentColor ? 0 : SCHACHBRETT_SIZE_X;
    bool breakFlag = false;
    for (int y = 0; y < 2; y++) {
        for (int x = 0; x < 8; x++) {
            if (breakFlag) {
                break;
            }
            if (getPieceWithOutColor(schachbrettInitialisierung[y][x]) == getPieceWithOutColor(piece)) {
                if (currentColor == colorPiece::black) {
                    if (soll_schachbrettFriedhof[colorPiece::white][y][x] == e_figuren::empty) {
                        soll_schachbrettFriedhof[colorPiece::white][y][x] = piece;
                        breakFlag = true;
                    }
                }
                else {
                    if (soll_schachbrettFriedhof[colorPiece::black][!y][x] == e_figuren::empty) {
                        soll_schachbrettFriedhof[colorPiece::black][!y][x] = piece;
                        breakFlag = true;
                    }
                }
            }
        }
        if (breakFlag) {
            break;
        }
    }
}
bool ZugCheck::moveFigure(int x, int y, int destX, int destY) {
    for(int x = 0; x < 8; x++){
        for(int y = 0; y < 8; y++){
            Serial.printf("%d ", soll_schachbrett[y][7-x]);
        }
        Serial.println();
    }
    Serial.printf("Aktuelle Figur: %d\n", soll_schachbrett[x][y]);
    if (getWhiteOrBlack(x, y) != currentColor) {
        printf("false Color\n");
        return false;
    }
    if (checkMove(x, y, destX, destY) == false) {
        printf("CheckMove false\n");
        return false;
    }
    if (soll_schachbrett[destX][destY] != e_figuren::empty) {
        stelleGeschlageneFigurZurueck(destX, destY);
    }
    soll_schachbrett[destX][destY] = soll_schachbrett[x][y];
    soll_schachbrett[x][y] = e_figuren::empty;
    currentColor = !currentColor;
    return true;
}

bool ZugCheck::checkMove(int x, int y, int destX, int destY) {
    if (!checkIfMoveIsOnTheChessfield(x, y, destX, destY)) {
        return false;
    }

    if (getWhiteOrBlack(x, y) == getWhiteOrBlack(destX, destY)) {
        return false;
    }

    bool flag = false;

    switch (getPieceWithOutColor(soll_schachbrett[x][y])) {
        case e_figuren::whitePawn:
            flag |= pawnCheck(x, y, destX, destY);
            break;
        case e_figuren::whiteTower:
            flag |= towerCheck(x, y, destX, destY);
            break;
        case e_figuren::whiteHorse:
            flag |= horseCheck(x, y, destX, destY);
            break;
        case e_figuren::whiteBishop:
            flag |= bishopCheck(x, y, destX, destY);
            break;
        case e_figuren::whiteQueen:
            flag |= queenCheck(x, y, destX, destY);
            break;
        case e_figuren::whiteKing:
            flag |= kingCheck(x, y, destX, destY);
            break;
    }
    return flag;
}

bool ZugCheck::pawnCheck(int x, int y, int destX, int destY) {

    int dir = (getWhiteOrBlack(x, y) == colorPiece::white) ? -1 : 1;
    int startRow = (dir == -1) ? 6 : 1;

    if (std::abs(destX - x) == 1 && destY == y + dir &&
        soll_schachbrett[destX][destY] != e_figuren::empty &&
        getWhiteOrBlack(destX, destY) != getWhiteOrBlack(x, y)) {
        return true;
    }

    if (destX != x) {
        return false;
    }

    if (destY == y + dir &&
        soll_schachbrett[x][y + dir] == e_figuren::empty) {
        return true;
    }

    if (y == startRow && destY == y + (2 * dir) &&
        soll_schachbrett[x][y + dir] == e_figuren::empty &&
        soll_schachbrett[x][y + (2 * dir)] == e_figuren::empty) {
        return true;
    }

    return false;
}
bool ZugCheck::towerCheck(int x, int y, int destX, int destY) {
    if (x == destX && y == destY) {
        return false;
    }
    if (x != destX && y != destY) {
        return false;
    }
    if (x == destX) {
        for (int i = 1; i < std::abs(destY - y); i++) {
            if (soll_schachbrett[x][y + (i * direction(y, destY))] != e_figuren::empty) {
                return false;
            }
        }
    }
    else if (y == destY) {
        for (int i = 1; i < std::abs(destX - x); i++) {
            if (soll_schachbrett[x + (i * direction(x, destX))][y] != e_figuren::empty) {
                return false;
            }
        }
    }
    //Rochade
    if (x == 0 && y == 0) {
        towerLeftMovedAlready[currentColor] = true;
    }
    else if (x == 7 && y == 0) {
        towerRightMovedAlready[currentColor] = true;
    }
    else if (x == 0 && y == 7) {
        towerLeftMovedAlready[currentColor] = true;
    }
    else if (x == 7 && y == 7) {
        towerRightMovedAlready[currentColor] = true;
    }
    return true;
}
bool ZugCheck::horseCheck(int x, int y, int destX, int destY) {
    if ((std::abs(destX - x) == 1 && std::abs(destY - y) == 2) ||
        (std::abs(destX - x) == 2 && std::abs(destY - y) == 1)) {
        return true;
    }
    return false;
}
bool ZugCheck::bishopCheck(int x, int y, int destX, int destY) {
    if (std::abs(destX - x) != std::abs(destY - y)) {
        return false;
    }
    for (int i = 1; i < std::abs(destX - x); i++) {
        if (soll_schachbrett[x + (i * direction(x, destX))][y + (i * direction(y, destY))] != e_figuren::empty) {
            return false;
        }
    }
    return true;
}
bool ZugCheck::queenCheck(int x, int y, int destX, int destY) {
    return bishopCheck(x, y, destX, destY) || towerCheck(x, y, destX, destY);
}
bool ZugCheck::raumZwischenKoenigUndTurm(bool tower) {
    int y = currentColor ? 0 : 7;
    //left true, right false -> enum towers
    int xbegin = tower ? 4 : 1;
    int xend = tower ? 7 : 3;
    if (getWhiteOrBlack(tower ? 0 : 7, y) != currentColor) {
        return false;
    }
    for (int x = 0; x < 8; x++) {
    }
    for (int x = xbegin; x < xend; x++) {
        if (soll_schachbrett[x][y] != e_figuren::empty) {
            return false;
        }
    }
    return true;
}
bool ZugCheck::kingCheck(int x, int y, int destX, int destY) {
    if (std::abs(destX - x) <= 1 && std::abs(destY - y) <= 1) {
        kingMovedAlready[currentColor] = true;
        return true;
    }
    //Rochade
    if (destY == y) {
        int y = currentColor ? 0 : 7;
        if ((((destX - x) == -2) && (kingMovedAlready[currentColor] == false && towerLeftMovedAlready[currentColor] == false)) && raumZwischenKoenigUndTurm(towers::towerLeft)) {
            soll_schachbrett[2][y] = soll_schachbrett[0][y];
            soll_schachbrett[0][y] = e_figuren::empty;
            return true;
        }
        if ((((destX - x) == 2) && (kingMovedAlready[currentColor] == false && towerRightMovedAlready[currentColor] == false)) && raumZwischenKoenigUndTurm(towers::towerRight)) {
            soll_schachbrett[4][y] = soll_schachbrett[7][y];
            soll_schachbrett[7][y] = e_figuren::empty;
            return true;
        }
    }
    return false;
}

bool ZugCheck::isKingAttacked(int x, int y) {
    return false;
}