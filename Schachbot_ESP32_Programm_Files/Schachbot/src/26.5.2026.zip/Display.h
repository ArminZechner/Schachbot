#pragma once
#include <SPI.h>
#include <TFT_eSPI.h>
#include "Common.h"
#include <string>
#define MAX_MASSAGE_SIZE 127
#define FIELD_SIZE_X 40
#define FIELD_SIZE_Y 30

class Display{
    public:
    Display();
    void setSelectedFields(Koordinate field1, Koordinate field2);
    void printChessfield();
    void printMessage(String message);
    void setChessBoard(char soll_schachbrett[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y], char soll_schachbrettFriedhof[2][SCHACHBRETT_SCHLAGBREITE][SCHACHBRETT_SIZE_Y]);
    private:
	char soll_schachbrett[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y];
	char soll_schachbrettFriedhof[2][SCHACHBRETT_SCHLAGBREITE][SCHACHBRETT_SIZE_Y];
    TFT_eSPI tft;
    String message;
    Koordinate selectedFields[2];
};