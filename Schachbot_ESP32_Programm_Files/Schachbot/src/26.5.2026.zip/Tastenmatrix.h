#pragma once
#include <Keypad.h>
#include "Common.h"
#define ROWS 4
#define COLS 4

class Tastenmatrix{
    public:
    Tastenmatrix();
    int getKey();
    void clearKeyMatrix();
    Koordinate getEingabe(uint8_t key);
    bool checkifBufferIsFull();
    char keys[ROWS][COLS] = {
        {'1','2','3','4'},
        {'5','6','7','8'},
        {'A','B','C','D'},
        {'E','F','G','H'}
    };
    private:
    byte rowPins[ROWS] = {27, 14, 12, 13};
    byte colPins[COLS] = {16, 17, 19, 21};

    Keypad kpd = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

    char keyBuffer[4];
};