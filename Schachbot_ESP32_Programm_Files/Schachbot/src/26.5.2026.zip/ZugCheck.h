#pragma once
#include "Common.h"

class ZugCheck{
public:
	ZugCheck() {
		init();
	}
	~ZugCheck() {
	}
	bool moveFigure(int x, int y, int destX, int destY);
	void init();
	char soll_schachbrett[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y];
	char soll_schachbrettFriedhof[2][SCHACHBRETT_SCHLAGBREITE][SCHACHBRETT_SIZE_Y];
	bool currentColor = 0;
private:
	char schachbrettInitialisierung[SCHACHBRETT_SIZE_Y][SCHACHBRETT_SIZE_Y] = {
	whiteTower, whiteHorse, whiteBishop, whiteQueen, whiteKing, whiteBishop,  whiteHorse, whiteTower,
	whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn, whitePawn,
	empty, empty, empty, empty, empty, empty, empty, empty,
	empty, empty, empty, empty, empty, empty, empty, empty,
	empty, empty, empty, empty, empty, empty, empty, empty,
	empty, empty, empty, empty, empty, empty, empty, empty,
	blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn, blackPawn,
	blackTower, blackHorse, blackBishop, blackKing, blackQueen, blackBishop,  blackHorse, blackTower
	};
	int getWhiteOrBlack(int x, int y);
	int direction(int pos, int dest);

	bool checkMove(int x, int y, int destX, int destY);

	void stelleGeschlageneFigurZurueck(int destX, int destY);
	bool checkIfMoveIsOnTheChessfield(int x, int y, int destX, int destY);
	int getPieceWithOutColor(int p);

	bool pawnCheck(int x, int y, int destX, int destY);
	bool towerCheck(int x, int y, int destX, int destY);
	bool horseCheck(int x, int y, int destX, int destY);
	bool bishopCheck(int x, int y, int destX, int destY);
	bool queenCheck(int x, int y, int destX, int destY);
	bool raumZwischenKoenigUndTurm(bool tower);
	bool kingMovedAlready[2] = { false, false };
	bool towerLeftMovedAlready[2] = { false, false };
	bool towerRightMovedAlready[2] = { false, false };
	bool kingCheck(int x, int y, int destX, int destY);

	bool isKingAttacked(int x, int y);
};

