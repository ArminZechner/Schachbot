#pragma once
#include <Arduino.h>
#include <string.h>
#define SCHACHBRETT_SIZE_X 12
#define SCHACHBRETT_SIZE_Y 8
#define SCHACHBRETT_SCHLAGBREITE 2

struct Koordinate{
    int8_t x;
    int8_t y;
};
struct MoveResult{
        String bestMove;
        String pv;

        int evaluation;
        int mateIn;
        int depth;

        bool success;
};
enum e_figuren{
		whitePawn,
		whiteTower,
		whiteHorse,
		whiteBishop,
		whiteQueen,
		whiteKing,

		blackPawn,
		blackTower,
		blackHorse,
		blackBishop,
		blackQueen,
		blackKing,

		empty
	};